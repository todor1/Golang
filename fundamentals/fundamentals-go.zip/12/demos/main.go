package main

func main() {

}

func Add(l, r int) int {
	return l + r
}
